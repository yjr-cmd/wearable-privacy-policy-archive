You can view this Privacy Policy in RingConn App and/or on the bottom of our website (https://www.ringconn.com) .

This Privacy Policy covers:

1. Introduction

2. What data we collect

3. How we use your data

4. For Users in the EU/EEA Region

5. For Users in California

6. Our policy for children

7. How data is shared and disclosed

8. How we store and transfer data

9. Data Retention and Security

10. What are your rights

11. Update to this privacy policy

12. Contact Information

1.INTRODUCTION

Shenzhen Ninenovo Technology Limited, and its affiliates (collectively “RingConn”, “we” or “us”)  “RingConn” knows how important privacy and personal data are to our customers.

This Privacy Policy is meant to help you understand what data we collect, why we collect it, how we process, store and protect it and how you can update, manage, export, and delete your data. Please take a moment to carefully review this policy.

This Privacy Policy applies to personal data collected and processed by us through our “Services” which includes: our RingConn devices (“Devices”) , Application (“App”) , websites, software, APIs, emails, newsletters and our services. If a separate privacy policy or user service agreement exists for a specific product or service, the privacy policy or user service agreement for that product or service will prevail. If the privacy policy or user service agreement for the product or service is not covered by such product or service, this Policy shall prevail. If one of our affiliated companies uses the products or services provided by us in their products or services but does not set up a separate privacy policy, this Policy shall also apply to such products or services. Unless otherwise agreed, the terms used in this Policy shall have the same meaning as those defined in the RingConn Terms of Use.

Please note that the Policy does not apply to information collected through other means, such as offline channels or any other website operated by the company or any third parties. Additionally, any third-party application or content (including advertisements) that may link to or be accessible from this website is not covered by this Policy. This policy is not intended to override the terms of any contact you have with us, not any rights you may have under other applicable data privacy laws. Please take a moment to familiarize yourself with our privacy protection practices. If you have any questions or concerns, please contact us at data\_protect@ringconn.com.

2. WHAT DATA WE COLLECT

When you use our Services, we collect the following types of data.

2.1 Information We Collect From You

Account and Profile Information: When creating an account, you provide us with your username, date of birth (month and year), gender (female, male, or prefer not to disclose), height, weight, email address, mobile number, password, and country/region. You may also choose to add a profile photo.

Health and Wellness Features:

Menstrual Cycle Tracking: If you activate this feature, and with your consent, we collect information such as your menstrual cycle timeline, period length, flow level, symptoms, alcohol or medication intake, and related sensor data from your RingConn device.

Sleep Apnea Monitoring (OSAHS): If enabled, and with your consent, we collect data such as height, weight, BMI, sex, age, neck circumference, medical history, sleep quality, and OSA-related symptoms.

Other Wellness Features: You may choose to enter additional wellness-related information, such as daily stress levels, mood, or notes related to your health.

User Communication: When you contact us, participate in feedback, surveys, contests, or promotions, we collect the information you submit, such as your name, contact information, and message content.

2.2 Information Automatically Generated and Collected

As part of our core service offering, your RingConn device and mobile App automatically generate and collect a wide range of wellness and device-related data, including:

RingConn Device Data:

The RingConn smart ring uses built-in sensors (such as PPG(a light-based sensor), accelerometers, temperature sensors, and SpO₂ sensors) to collect raw measurement data.

These measurements are used to estimate and generate a wide range of biometric and activity data, including:

Sleep tracking data: sleep stages, duration, quality, and related vital signs (e.g., heart rate, respiratory rate, skin temperature, blood oxygen levels during sleep).

Heart rate and HRV(the variation in time between heartbeats): real-time heart rate, heart rate variability, and trends over time.

Blood oxygen (SpO₂): levels of blood oxygen, especially during sleep.

Respiratory rate: breathing rate during sleep or rest periods.

Stress and recovery metrics: data related to stress detection and stress management recommendations.

Daily activity tracking: step count, active minutes, calories burned, activity intensity, and sedentary behavior.

Vital signs monitoring: including skin temperature trends and fluctuations.

Periodic Wellness Reports: Based on the collected metrics, the App may generate personalized weekly, monthly, or annual wellness reports which summarize your sleep, activity, readiness, and overall health trends.

App Data:

Device and System Information: Device identifiers, synchronized RingConn device data, mobile OS version, system language, browser type, and IP address.

App Usage and Activity Logs: Interactions with app features, navigation behavior, search history, and user-generated content.

Performance Data: Diagnostic logs, crash reports, performance statistics, and feature usage analytics.

Location Data:

If you enable Bluetooth and location access, we may collect approximate or precise location data to ensure proper Bluetooth connectivity, find-your-device features, and data synchronization. This data may be gathered via GPS, Wi-Fi, or network provider data, and only with your consent.

We do not collect or use precise location data without your explicit permission, which can be revoked at any time in your device settings.

We may also derive approximate location based on your IP address for regional service optimization.

Third-Party SDK Data:

Integrated SDKs may collect device parameters, app logs, and limited analytics data as necessary for their operations.

Some SDKs may request access to the device’s MAC address or app installation list. RingConn does not authorize or encourage the collection of unnecessary or sensitive device-level data by third parties.

2.3 Information From Third Parties

We may collect information from third-party sources when you choose to integrate or log in using third-party accounts or platforms:

Social Media and Login Providers:

If you sign in or link your account via Google or Apple, we receive data such as your account display name and profile photo from those services.

Health Platforms and Integrations (if supported):

You may choose to sync your RingConn data with third-party health platforms (e.g., Apple Health, Google Fit), in which case, we may receive or share certain health metrics according to your permissions and settings in those platforms.

2.4 Customer Service Information

When you use the in-app online customer service feature, to verify your identity, efficiently identify, and resolve the issues you encounter, we will collect and use the following information:

Account Identification Information: Including your RingConn User ID and device serial number (SN).

Basic Profile Information: Your chosen appellation, and contact email address.

Device Information: The type of ring you are using.

Communication Content: The complete record of your communication with our customer service, including problem descriptions, screenshots, or other files you provide. This information is necessary to provide customer support services and helps us quickly understand your issue and provide you with an accurate solution.

3. HOW WE USE YOUR DATA

We use the personal data we collect for the following purposes.

3.1 To Provide and Maintain Our Services

We process your personal data to deliver and operate our Services effectively. For example, we use your health-related metrics to generate daily insights regarding your heart rate variability, sleep, and activity levels.

Subject to the notification permissions you grant, certain features may be activated automatically to enhance your experience—such as reminders and functional alerts—to ensure you receive important and timely updates related to the Application.

3.2 To Improve and Develop Our Products and Services

We use personal data, including via third-party software development kits (SDKs), to improve product performance, enhance usability, and develop new features. This may include SDKs for crash diagnostics, push notifications, third-party logins, mapping, and location-based services.

We may process data such as device specifications, app logs, location data (e.g., IP-derived or GPS-based), unique application identifiers, and Android ID using the Sensors Data SDK. Where feasible, such processing will involve pseudonymized, aggregated, or otherwise non-identifiable information to protect your privacy.

We also process firmware update-related technical data to enhance device stability, ensure compatibility across software versions, and proactively address performance or security vulnerabilities.

If you grant access to your location data and enable mapping or navigation features within the App, we may use third-party mapping SDKs to provide the requested services. These SDKs may collect additional information, including your precise location, device type, hardware parameters, and system information.

3.3 To Provide Customer Support and Online Customer Service

We process personal data to provide customer service, including managing real-time communication with you through the online customer service feature. When you contact our support team regarding device, application data, or any other issues, we will use the Account Identification Information, Basic Profile Information, Device Information, and Communication Content you provide to process your inquiry, verify your identity, track the progress of issue resolution, and help resolve your problems.

3.4 To Comply with Legal Obligations

We may process your personal data as necessary to comply with legal and regulatory requirements, such as those related to accounting, taxation, legal claims, or other statutory obligations.

4. FOR USERS IN THE EU/EEA REGION

Where the General Data Protection Regulation (GDPR) is applicable to RingConn in accordance with the law, the information and the rights specified in this section are available to users residing in the EU/EEA region.

We act as a "controller" for the Services in which we determine how personal information is utilized in relation to our offerings. Conversely, we function as a "processor" for the Services where we handle personal information solely in accordance with our customers' instructions, as according to the GDPR.

4.1 Legal Basis for Data Processing

The table below provides the ways we plan to use your personal data and which legal bases we rely on. We have also identified what our legitimate interests are where appropriate.

Note that we may process your personal data for more than one lawful ground depending on the specific purpose for which we are using your data. Please contact us if you need details about the specific legal ground, we rely on to process your personal data where more than one ground has been set out in the table.

Purpose / Activity

Type of Data

Legal Basis for Processing

Account registration and profile creation

Username

Email address

Mobile number

Password

Date of birth (month and year)

Gender

Height and weight

Region/country

Profile photo (optional)

Performance of a contract with you

Device pairing and operation

Bluetooth connection data

Device ID and serial number

Firmware version

Connection logs

Performance of a contract with you

Daily activity tracking

Step count

Calories burned

Activity level and intensity

Movement data (from accelerometer)

Sedentary behavior data

Performance of a contract with you

Sleep monitoring and reports

Sleep stages (light, deep, REM)

Sleep duration and quality

Nighttime heart rate

Blood oxygen during sleep

Respiratory rate during sleep

Skin temperature trends during sleep

Performance of a contract with you

Stress and recovery management

Heart rate variability (HRV)

Stress level trends

Recovery metrics

User-inputted mood/stress levels

Performance of a contract with you

Heart rate and SpO₂ monitoring

Real-time and average heart rate

Heart rate trends

Blood oxygen (SpO₂) levels

Performance of a contract with you

Vital signs monitoring

Skin temperature

Respiratory rate

Resting heart rate

Changes in physiological signals

Performance of a contract with you

Weekly, monthly, and annual wellness reports

Aggregated sleep, activity, and heart rate data

Summary charts

Trend analytics

Personal recommendations

Performance of a contract with you

Menstrual cycle tracking (optional feature)

Menstrual cycle timeline

Period start/end dates

Flow level

Symptoms

Alcohol/medication notes

Body signals from the device (optional)

Consent

Obstructive Sleep Apnea Syndrome (OSAHS) screening (optional feature)

Height, weight, BMI

Age, sex, neck circumference

Medical history

OSAHS symptoms

Sleep reports

Consent

App usage analytics and troubleshooting

Crash logs

Diagnostic logs

Feature interaction data

App navigation patterns

Legitimate interests (to improve services)

Mobile device and system identification

Model

Operating system

Screen size

Unique device identifier

IMEI

MAC address

Browser type

Network provider

Language and time zone

Push code

Performance of a contract with you

Bluetooth and location services (for device connectivity)

Bluetooth signal data

Approximate GPS location (if permitted)

Wi-Fi/Bluetooth SSID info

Consent

SDK-related third-party analytics

Device information

App usage data

Installation list (if collected)

Crash data

Legitimate interests (for app functionality and performance)

Customer support and communication

Name

Email

Message content

App version and device data

Feedback or survey answers

Performance of a contract with you

Login via third-party platforms (e.g., Google, Apple)

Third-party account ID

Display name

Profile photo

Performance of a contract with you

Integration with health platforms (e.g., Apple Health, Google Fit)

Health metrics shared via APIs (based on user permission)

Consent

Providing Online Customer Service

RingConnID, DeviceSN, UserAppellation, ContactEmail, RingType, CommunicationContent.

Performance of a contract with you (necessary to fulfill our contractual obligations to provide you with customer support).

4.2 Your Rights

This section describes your GDPR rights. Please note that for security reasons, we may verify your identity before processing your request.

Right to access personal information: You have the right to obtain confirmation from us that we process your personal information and, if so, you may have the right to request access to your personal information. You can directly inquire or access your personal data in our product or service interface after logging in to your account. You can also query and access your personal data through RingConn app feedback or emailing us at data\_protect@ringconn.com.

Right to data portability: You are entitled to obtain a copy of your personal data in structured, commonly used and machine-readable formats to the extent permitted by laws and regulations. For example, if you decide to change to a new service provider, you can move, copy or transfer your personal data between our IT-system and their IT system in a reliable, secure and easy way without affecting its use.

Upon providing formal authorization, you can exercise your right to data portability by contacting us via the feedback feature on RingConn app, or by sending an email to data\_protect@ringconn.com.

Right to rectification of personal information: You have the right to request that we rectify inaccurate personal information concerning you and, depending on the purposes of the processing, you may have the right to have incomplete personal information completed. You can directly rectify and modify part of your personal data on the related function pages of products or services or contact us at data\_protect@ringconn.com.

Right to erasure/deletion: You have the right to request us to erase some or all of the personal information concerning you. You can directly erase/delete your submitted information in the product interface under your account. You can also contact us via the feedback feature on our platform or by emailing us at data\_protect@ringconn.com.

Right to restriction of processing: You have the right to request us to restrict the further processing of your personal information. In such cases, the respective information will be marked as restricted. We will store the data and process it for the sole purpose of responding to your request or with your consent in the future. You can submit the request to data\_protect@ringconn.com.

Right to object: You have the right to object, on grounds relating to your particular situation, such as legitimate interests, exercise of public authority, direct marketing (including data pooling), and statistical reasons, to the processing of your personal information by us. You can submit the request to data\_protect@ringconn.com.

Right to object to direct marketing: You have the right to object to the processing of personal information for direct marketing purposes. You can submit the request to data\_protect@ringconn.com. If you no longer wish to receive our commercial advertisement, you can unsubscribe at any time via the feedback feature on our platform or by emailing us at data\_protect@ringconn.com.

Right to withdraw consent: Where we rely on your consent to process your data, you have the right to withdraw consent you have provided to us at any time, and we will stop further processing. You can always provide your consent to us again at a later time. You can submit the request via the feedback feature on our platform or by emailing us at data\_protect@ringconn.com.

Right to refuse automated decision-making: Under the GDPR, you have the right not to be subject to decisions made by automated processing, including profiling, where the decision has a significant legal impact on you. We do not process your information in this manner. If you have any questions or concerns, please feel free to contact us at data\_protect@ringconn.com.

Right to complaint: You have the right to lodge a complaint to an applicable supervisory authority or other regulators if you are not satisfied with our responses to your requests or how we manage your personal information.

Health and other special categories of personal data：To the extent that data we collect is health data or another special category of personal data subject to the GDPR, we ask for your explicit consent to process the data. We obtain this consent separately when you take actions leading to our obtaining the data, for example, when you pair your device to your account. You can use your account settings in App and settings in your mobile device to withdraw your consent at any time, including by unpairing your device, or deleting your data or your account.

We encourage you to first or also reach out to us at data\_protect@ringconn.com, so we have an opportunity to address your concerns directly. We will respond to your request within 30 days from the date of receiving your request and communicate with you in an appropriate way.

5. FOR USERS IN CALIFORNIA

5.1 Data Collection

In such cases where the California Consumer Privacy Act of 2018 (CCPA) and its amendment are applicable, the information and the rights specified in this section are available to users residing in California.

We collected the following categories of personal information from consumers within the last twelve (12) months:

Categories

Information

Data Sharing

Identifiers

Name or alias

Email address

Phone number

Account name

Device serial number

IMEI number

MAC address

Unique device ID

AD ID

RingConn User ID

Yes: Shared with analytics and SDK providers (e.g., Google Firebase) for performance and error tracking; shared with customer support platform.

Contact Information

Name

User Appellation

Email address

Phone number

Region or country

Yes: With customer support platforms and third-party communication tools.

Protected Classification Characteristics

Gender

Birth month and year

No.

Biometric Information

Heart rate

Blood oxygen (SpO₂)

Sleep stage data

Skin temperature

Respiratory rate

Heart rate variability (HRV)

No.

Internet or Other Network Activity

App usage history

Crash logs

In-app navigation data

Feature interaction data

Yes: Shared with analytics SDKs (e.g., Firebase) to improve app performance and user experience.

Geolocation Data

Approximate or precise location (only if user enables GPS for Bluetooth pairing)

No.

Sensory Data

None collected directly (no voice, video, or photo unless user uploads profile photo)

No

Health Information (inferred)

Activity level

Stress level

Menstrual cycle prediction

Sleep quality trends

No.

Device-Related Information

Phone model

Operating system

Screen size

System language

Network provider

Push notification ID

Time zone

Yes: Shared with third-party SDKs for app operation and push services.

Inferences Drawn from Other Personal Information

Personalized health reports

Predicted stress level or cycle stage based on sensor data

No.

Third-party Login Credentials

Apple ID, Google account display name (if third-party login is used)

Yes: With login provider, as required to support authentication.

Other personal information

Ring Type, Customer Service Communication Records

Yes: Shared with customer support platform.

5.2 Your Rights

The CCPA provides consumers (California residents) with specific rights regarding their personal information. This section describes your CCPA rights. Requests may be submitted directly by the users or their authorized agent, if applicable.

Right to know and access: You have the right to request RingConn to disclose certain information to you about our collection and use of your personal information over the past 12 months. Once we receive and confirm your verifiable consumer request, we will disclose to you:

• The categories of personal information we collected about you.

• The categories of sources for the personal information we collected about you.

• Our business or commercial purpose for collecting or sharing that personal information.

• Whether we share or sell your personal information, and if so, the categories of third parties with whom we share that personal information.

• The specific pieces of personal information we collected about you (also called a data portability request).

• If we disclose your personal information for a business purpose, we will identify the personal information categories that each category of recipient obtained.

You can directly inquire or access your personal data in our product or service interface after logging in to your account. You can also query and access your personal data through RingConn app feedback or emailing us at data\_protect@ringconn.com.

Right to data portability: You are entitled to obtain a copy of your personal data in structured, commonly used and machine-readable formats to the extent permitted by laws and regulations. For example, if you decide to change to a new service provider, you can move, copy or transfer your personal data between our IT system and their IT system in a reliable, secure and easy way without affecting its use.

Upon providing formal authorization, you can exercise your right to data portability by contacting us via the feedback feature on RingConn app, or by sending an email to data\_protect@ringconn.com.

Right to rectification of personal information: You have the right to request that we rectify inaccurate personal information concerning you and, depending on the purposes of the processing, you may have the right to have incomplete personal information completed. You can directly rectify and modify part of your personal data on the related function pages of products or services or contact us at data\_protect@ringconn.com.

Right to erasure/deletion: You have the right to request us to erase some or all of the personal information concerning you. You can directly erase/delete your submitted information in the product interface under your account. You can also contact us via the feedback feature on our platform or by emailing us at data\_protect@ringconn.com.

Right to opt-out of the selling or sharing of personal information: while we do not sell your information, there are occasions where we will have to transfer information to third-party service providers to operate and maintain our services. If you would like to inquire more or opt-out of such sharing, please contact us at data\_protect@ringconn.com.

Right to limit the use of sensitive personal information: we will not process your sensitive information for purposes outside of those previously communicated to you at the time of collection. If you have any concerns, please contact us at data\_protect@ringconn.com.

Non-discrimination: We will not discriminate against you for exercising any of your CCPA rights. Unless permitted by the CCPA, we will not:

• Deny you goods or services.

• Charge you different prices or rates for like-goods or services, including through granting discounts or other benefits, or imposing penalties.

• Provide you with a different level or quality of like-goods or services.

• Suggest that you may receive a different price or rate for like-goods or services or a different level or quality of like-goods or services.

Other California Privacy Rights: California's "Shine the Light" law (Civil Code Section § 1798.83) permits users of our websites, other products, services and platforms that are California residents to request certain information regarding our disclosure of personal information to third parties for their direct marketing purposes.

6. OUR POLICY FOR CHILDREN

We define “children” as individuals (i) under the age of 16 residing in the EU/EEA, (ii) anyone under 13 residing in all other regions, or (iii) individuals who qualifies as “children” under the applicable data protection laws of their respective jurisdiction. We do not knowingly collect personal information from children. Children may not register for an account on our Platform or send us personal information such as their names, address, phone numbers, email address, etc., unless permitted by local law and their guardians have given their consent. We will only use or publicly disclose personal information collected from children with the consent of their guardians as permitted by law, with the consent of the guardian, or as necessary to protect the child. We do not sell or share children’s data under the definition of the California Consumer Privacy Act (CCPA) and its regulations.

If we become aware that we have collected personal information from a child without the consent of the child's guardian, we will delete the data as soon as we are aware of it. If you believe that we may improperly hold personal information from or about a child, please contact us.

7. HOW DATA IS SHARED AND DISCLOSED

We do not sell personal data of our users. We do not share your personal data except in the limited circumstances described below.

Special Note: Currently in the Android system, the third-party services we use attempt to read the user's list of installed applications. However, since our App has not been granted permission to access the user's list of installed applications, third parties cannot read this information.

7.1 External Processing by Third Parties

We share your personal data with certain trusted partners, including our affiliates, service providers, and technical vendors—for the purposes of delivering our Services, maintaining our platform, and supporting business operations. We require our partners to process your personal data based on our instructions, and in compliance with this policy and any other appropriate confidentiality and security measures. We also require these partners to protect your personal data to at least the same standards that we do.

We use external processing services such as:

(1) storing our users’ data;

(2) providing customer services (including Online Customer Service): We use third-party customer support platforms and online chat tools to operate our online customer service system. For this purpose, we share your RingConnID, DeviceSN, UserAppellation, ContactEmail, RingType, and CommunicationContent with these platforms to ensure support agents can assist you. These service providers may only process this data according to our instructions and are bound by strict confidentiality obligations;

(3) managing and organizing our marketing activities. We only share website usage data with our advertising network partners for the purposes of analyzing and optimizing our marketing. We do not share the health-related data or other sensitive personal data with third party advertisers.

(4) analyzing information regarding the use of our online service to improve our service quality.

7.2 With Your Consent or at Your Direction

(1) Sharing with Third-Party Applications

We may share your personal data with third parties only with your explicit consent or at your direction. This includes the following scenarios:

When you authorize third-party applications (such as Apple Health or Google Fit) to access your data, we may share relevant health data with them based on your instructions. Please note that the use of your data by these third parties will be governed by their respective privacy policies and terms. We recommend that you review those policies carefully.

You can revoke your consent at any time via your account settings.

RingConn uses the following Google Fit scopes to sync your health data (e.g. sleep, heart rate, oxygen saturation) with your Google Fit account:

https://www.googleapis.com/auth/fitness.sleep.write

https://www.googleapis.com/auth/fitness.sleep.read

https://www.googleapis.com/auth/fitness.heart\_rate.write

https://www.googleapis.com/auth/fitness.body\_temperature.write

https://www.googleapis.com/auth/fitness.oxygen\_saturation.write

https://www.googleapis.com/auth/fitness.body.write

https://www.googleapis.com/auth/fitness.activity.write

RingConn’s use and transfer of information received through Google APIs fully complies with the Google API Services User Data Policy, including the Limited Use requirements.

(2) Sharing with Friends and Family (Optional Feature)

If you choose to enable the "Shared with Friends and Family" feature in the Application, you consent to the sharing of your personal health data—including your weekly health reports, sleep data, activity data, stress levels, vital signs, and any high heart rate abnormalities—with other registered users of the Application whom you have explicitly invited.

These shared data may include measurements and metrics collected by your RingConn device, as well as any information you voluntarily provide while using the Application.

Sharing is facilitated through a one-time-use invitation link, which you control. You may stop sharing your data at any time by removing a user from your sharing list. Once a user is removed, they will no longer have access to any previously shared reports.

By enabling this feature, you consent to the sharing of your data solely for the purpose of enhancing your experience and enabling support from people you trust. If you do not wish to share your data, please do not activate this feature.

Important Notice for Recipients of Shared Data:

If you are invited by another registered user to access their shared health data, including weekly reports, sleep and activity metrics, stress levels, vital signs, or high heart rate abnormalities, you agree not to disclose, forward, copy, download, or share such data with any third parties who are not authorized by the data owner. Any misuse or unauthorized use of shared data may violate privacy laws. RingConn is not liable for any legal consequences arising from inappropriate or unlawful actions taken by recipients of shared data.

(3) Account Synchronization Across Platforms

To provide a seamless and consistent user experience across platforms, we support account interoperability between different platforms, including our application and website. When you create an account or make a purchase on one platform, we may synchronize the account and related information on the other platform to integrate services.

When you create an account on the App, we will also generate a corresponding account on the Website with the same initial password and password rules. Conversely, creating an account on the Website will result in a corresponding account on the App. Password changes on one platform will not be automatically synced to the other.

If you make a subscription purchase using an existing App account and we detect a matching email account on the Website, we will automatically link both accounts so you can view unified purchase records and manage your subscription from either side. If no Website account exists, we will create one and complete the linking automatically.

To support these features, we may process and sync the following data:

• Basic account information (e.g., email, username, user ID).

• Purchase and subscription history.

• Account status and login activity.

Please note that we will not use or share your sensitive data for undisclosed purposes without your explicit permission. You can review and manage your data processing preferences in your privacy settings.

7.3 Legal Compliance and Law Enforcement

We reserve the right to disclose personal data to protect our legal rights and property; and to comply with valid legal requirements.

We may preserve or disclose data about you to comply with a law, regulation, legal process, or governmental request; to assert legal rights or defend against legal claims; or to prevent, detect, or investigate illegal activity, fraud, abuse, violations of our terms, or threats to the security of the Services or the physical safety of any person.

We may share non-personal data that is aggregated so that it cannot reasonably be used to identify an individual with or without combining additional information. We may disclose such data publicly and to third parties, for example, in public reports about exercise and activity, to partners under agreement with us, or as part of the community benchmarking data we provide to users of our subscription services.

We will not transfer your personal information to any companies, organizations or individuals, except in the following circumstances:

a) Transfer with explicit consent: We will transfer your personal information to other parties after obtaining your explicit consent.

b) In cases involving merger, acquisition, or sale of assets, we will continue to take measures to protect the personal data privacy and give affected users notice before transferring any personal data to a new entity. Where a transfer of personal data is involved, we will require the new entity to continue to be bound by this privacy policy before we requested to seek independent consent from you to collect and process your data.

8. HOW WE STORE AND TRANSFER DATA

As we provide our Products or Services through resources and servers around the world, we process and back up personal data through a global operating and control infrastructure.

(1) If you use our Services, the personal information we collect from and generate in the People's Republic of China will be stored on servers in the People's Republic of China.

(2) If you use our Services, the personal Information that we collect and generate outside the People's Republic of China will be stored on servers outside of the People's Republic of China, including in jurisdictions other than the one in which the data was collected, or subject to access from such jurisdictions.

(3) Currently, we use cloud servers deployed in the [UK] to process personal data of users in the United States, the United Kingdom and the European Economic Area (EEA).

We rely on multiple legal basis to lawfully transfer personal data around the world. These include your consent (if applicable) and EU Commission approved model contractual clauses, which require certain privacy and security protections. You may obtain copies of the model contractual clauses by contacting us. We are subject to the oversight of the US Federal Trade Commission and remains responsible for personal data that we transfer to others who process it on our behalf as described in “HOW DATA IS SHARED AND DISCLOSED” section.

If you have a complaint about our international data transfer, please contact us by means described in “CONTACT INFORMATION” section. You may make a complaint to the competent regulatory authority in your jurisdiction.

9. DATA RETENTION AND SECURITY

9.1 Data Retention

We will only store your personal information for as long as necessary for the purposes described in this Policy and for as long as required by law, regulation and supervision, unless there is a mandatory retention requirement by law. If we terminate the service or operation, we will promptly stop the activities of continuing to collect your personal information, and, unless otherwise required by applicable laws and regulations, delete or anonymize your personal information. Where the immediate deletion is not possible, for example, because your Personal Information has been stored in backup archives, then we will securely store your Personal Information and isolate it from any further processing until deletion is possible. If we anonymize your personal information (so that it can no longer be associated with you), we may use this information indefinitely without further notice to you.

9.2 Data Security

We have taken reasonable and practicable security measures, consistent with industry standards, to protect your information from unauthorized access, disclosure, use, modification, damage or loss of personal information. We take the following steps to keep your data secure:

(a) Using encryption technology to improve the security of personal information.

(b) Use of trusted protection mechanisms to prevent malicious attacks on personal information.

(c) Deploy access control mechanisms and make every effort to ensure that only authorized personnel have access to personal information.

(d) Conducting security and privacy training courses to enhance employees' awareness of the importance of protecting personal information.

(e) Specialized data compliance management systems, processes and organizations are in place to safeguard information. For example, we strictly limit the scope of people who access information, require them to comply with confidentiality obligations, and conduct audits.

We will take all reasonably practicable steps to ensure that no unrelated personal information is collected. We will retain your personal information only for the shortest period necessary to achieve the purposes described in this Policy, unless otherwise required by the laws and regulations of your location.

The Internet environment is not 100% secure and we will endeavor to ensure or warrant the security of any information you send us. If our physical, technical, or administrative safeguards are compromised, resulting in unauthorized access, public disclosure, tampering, or destruction of information, resulting in damage to your legal rights and interests, we will assume appropriate legal liability. After the unfortunate occurrence of personal information security events, we will strictly follow the requirements of the laws and regulations of your location and inform you in a timely manner of: the basic situation and possible impact of the security event, the disposal measures we have taken or will take, the suggestions you can independently prevent and reduce the risk, the remedial measures for you, etc. We will promptly inform you of the event-related situation by email, letter, telephone, push notification, etc. When it is difficult to inform the subject of personal information one by one, we will take a reasonable and effective way to issue an announcement. At the same time, we will also take the initiative to report the disposal of personal information security incidents and fulfill the obligations stipulated in other laws and regulations in accordance with the requirements of regulatory authorities.

10. WHAT ARE YOUR RIGHTS

10.1 Your Rights Under Applicable Laws

You have rights and choices to your data under applicable laws. Some of these rights apply generally, while others will only apply in certain circumstances. Depending on the scenario, these rights may be subject to some limitations. Please note that by exercising some of your following rights, for example, by withdrawing your consent to our Privacy Policy, we may not be capable to maintain our Services to you.

You may choose to exercise the following rights about your data:

(1) Right of confirmation and access. You can ask us to confirm whether your data has been processed, or request access to your data and receive a copy of personal data we have collected and stored about you.

(2) Right of rectification. You can update, rectify or change your data in the account settings of App. You can ask us to update, rectify or change your data where that data is not accurate.

(3) Right of erasure. You have right as provided by applicable laws to request us to erase, destroy, or anonymize your personal data. You may request us to cease the supply of personal data to a third party under certain circumstances according to applicable laws.

(4) Right of portability. You have the right to data portability in circumstances where we rely on contractual necessity and consent as our legal basis. This means that you have the right to receive your data in a structured, commonly used, and machine-readable format and to share it with a third party.

(5) Right to withdraw consent. You can withdraw consent to the processing of personal data based on your consent, unless such withdrawal is restricted by the law or by contract.

However, withdrawal does not affect the legitimacy and effectiveness of how we process your personal data based on your consent before the withdrawal is made.

a. You can withdraw your consent in the account settings of your App.

b. If you want to unsubscribe from the electronic communications, please see your notification settings under account settings of your App to control our marketing communications to you.

(6) Right to object or restrict processing. You have the right to object to or restrict our processing of your data in certain circumstances, relying on legitimate interest or public interests on the basis of applicable laws. For example, according to applicable laws, you may require us to cease or not to begin processing their personal data for purposes of direct marketing. You may object to decision-making based solely on automated processing related to your profile, under certain circumstances according to applicable laws.

In submitting an objection or restriction request, you should explain what specific processing activity you are objecting to or should be restricted, and why the processing should be stopped. We will stop the particular processing if we don’t have compelling legitimate grounds to continue that processing or don’t need it for legal claims.

10.2 How to Exercise Your Rights

You may exercise these rights by logging into your account and using your account settings, or contacting us as specified in the “CONTACT INFORMATION” section in writing or by other means permitted by applicable laws.

We will ensure you can exercise your rights in accordance with the applicable laws. Depending on the applicable laws, there may be situations where we may refuse your requests, for example, when refusing is in pursuant to a court order, or exercising your rights would adversely affect the rights and freedom of others.

When you need to exercise your rights, we may ask you to authenticate your identification, such as through your RingConn account.

Normally, you don’t have to pay us when you’re exercising your rights under the applicable laws; however, we reserve the right to charge you a reasonable fee for the processing of any data access, correction request or other scenarios where charge of fee is permitted by applicable laws.

We will respond to your requests within the time limits provided under applicable laws in the country/regions of your residence.

If you have any questions regarding this Privacy Policy or about exercising your rights, you may send your request in writing to the email address we provide below in “CONTACT INFORMATION”.

If you are of the opinion that the processing of your personal data by us is not in compliance with this Privacy Policy or applicable laws, you have the right to make a complaint to the competent regulatory authority in your jurisdiction.

11. UPDATE TO THIS PRIVACY POLICY

This Policy may be updated to provide you with better service and as our business evolves. However, we will not reduce your rights under this Policy without your consent. We will notify you before we make material changes to this policy and give you an opportunity to review the revised policy before deciding if you would like to continue to use the Services. You can review previous versions of the policy at our website ( https://www.ringconn.com ) .

We will not reduce your rights under this Privacy Policy without your express consent. We will post any changes to this policy on this page.

For material changes, we will also provide more prominent notice (including, for certain Services, email notification of specific changes to the Privacy Policy).

Material changes within the meaning of this Policy include, but are not limited to:

a. Significant changes to our service model. For example, the purpose of processing personal information, the type of personal information processed, and how personal information is used.

b. Significant changes in our ownership structure, organisational structure, etc. Such as changes in ownership caused by business restructuring, bankruptcy and mergers and acquisitions.

c. Changes in the primary recipients of personal information shared, transferred, or publicly disclosed.

d. Significant changes in your right to participate in the handling of personal information and the manner in which it is exercised.

e. Changes in the department responsible for handling personal information security, contact information and complaint channels.

f. When the security impact assessment report of personal information indicates that there is a high risk.

12. CONTACT INFORMATION

If you have questions about this policy, or need help exercising your privacy rights, please contact our Data Protection Officer at

data\_protect@ringconn.com

You may contact us at:

Shenzhen Ninenovo Technology Limited

Address: Room B801, National Engineering Laboratory Building, No. 20 Gaoxin South 7th Road, Gaoxinnan Community, Yuehai Subdistrict, Nanshan District, Shenzhen，China.

Customer Support Email Address：

cs@ringconn.com