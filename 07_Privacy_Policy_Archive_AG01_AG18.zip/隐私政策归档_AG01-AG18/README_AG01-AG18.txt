Privacy policy document archive for Round 2 revision

This folder contains only the 18 final device-document cases retained in the second-round revision.
File prefixes are zero-padded (AG01-AG18) so that files appear in the manuscript sample order.
The manuscript case IDs remain AG1-AG18.

Subfolders:
01_markdown_texts: machine-readable Markdown text files used for evidence checking and coding.
02_original_policy_files: source-format files retained as document snapshots where available.

The mapping between final case IDs and earlier file IDs is recorded in manifest_AG01-AG18.tsv.
Excluded earlier cases are not copied into this archive.
